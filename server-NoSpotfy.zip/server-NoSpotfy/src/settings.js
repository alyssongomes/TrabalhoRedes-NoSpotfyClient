var os  = require('os')
var contentFolder = os.homedir() + '/MusicServer/';

exports.contentFolder = contentFolder;
